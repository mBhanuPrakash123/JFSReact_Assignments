var fullName = {
  firstName: "Shreya",
  lastName: "Doe",
};

console.log(
  "Before initializing data the values are " +
    fullName.firstName +
    " " +
    fullName.lastName
);

fullName.lastName = "Ghoshal";
console.log(
  "After initializing data the values are " +
    fullName.firstName +
    " " +
    fullName.lastName
);

